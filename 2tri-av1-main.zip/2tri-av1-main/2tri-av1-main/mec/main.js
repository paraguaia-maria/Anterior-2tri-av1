var cxPrincipal = document. querySelector ("cx-principal");
var cxPerguntas = document. querySelector ("cx-perguntas")
var cxAlternativas = document. querySelector ("cx-lternativa")
var cxResulado = document. querySelector ("cx-resultado")
var cxResultado = document. querySelector ("cx-resultado")
var peguntas=[
{
    enunciado: "A IA pode automatizar tarefas repetitivas.",
    alternativa:[
        "Vai eliminar tarefas monotonas", "Vai tirar muitos empregos"
    ]
},
{
    enunciado: "",
    alternativa:[
        "", ""
    ]
},
{
    enunciado: "",
    alternativa:[
        "", ""
    ]
},
{
    enunciado: "",
    alternativa:[
        "", ""
    ]
},
{
    enunciado: "",
    alternativa:[
        "", ""
    ]
}
]
